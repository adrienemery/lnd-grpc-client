# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lndgrpc', 'lndgrpc.aio']

package_data = \
{'': ['*']}

install_requires = \
['aiogrpc>=1.8,<2.0',
 'googleapis-common-protos>=1.53.0,<2.0.0',
 'grpcio-tools>=1.37.0,<2.0.0',
 'grpcio>=1.37.0,<2.0.0',
 'protobuf3-to-dict>=0.1.5,<0.2.0',
 'protobuf>=3.15.8,<4.0.0']

setup_kwargs = {
    'name': 'lndgrpc',
    'version': '0.2.3',
    'description': 'An rpc client for LND (lightning network deamon)',
    'long_description': None,
    'author': 'Kornpow',
    'author_email': 'test@email.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>3.6',
}


setup(**setup_kwargs)
